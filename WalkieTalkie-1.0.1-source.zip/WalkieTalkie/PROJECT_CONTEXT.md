# Walkie Talkie: Project Context

This document describes the whole app so it can be changed safely without reading every file first. It is accurate for **version 1.0.1 (versionCode 11, protocol version 3)**.

- Repository: https://github.com/AsifMinar/WalkieTalkie (public)
- Package: `com.walkietalkie.wifi`
- Size: about 4,800 lines of Java, APK about 58 KB

---

## 1. What the app is

A push-to-talk walkie-talkie for Android that works **only over local Wi-Fi**. There's no internet, server or account. Phones on the same Wi-Fi network, or connected to one phone's hotspot, discover each other with UDP broadcasts and send voice directly to each other, end-to-end encrypted.

Main features:
- Hold to talk to everyone on your channel; slide up to lock talking hands-free.
- 16 channels.
- Private calls: hold a person's name to talk to only them, whatever channel they're on.
- Automatic discovery of everyone on the same network.
- Works when one of the phones is the hotspot.
- Messages that arrive while the line is busy are held and played afterwards.
- Optional background listening through a foreground service and notification.
- Synthesized radio sounds: static, talk-permit chirp, roger beep.
- Nothing is ever recorded or stored. Audio exists only in RAM while it plays.

---

## 2. Rules for working on this project

1. **No Gradle, no Android Studio, no AndroidX, no third-party libraries.** Only the Android framework API and the Java standard library. The build is `build.sh` (section 4).
2. **Java language level 8** (`javac -source 8 -target 8`). Use **anonymous inner classes, not lambdas or method references.** The whole codebase uses anonymous classes, and the build has no desugaring step, so lambdas would fail on the phone.
3. **minSdk 31 (Android 12), targetSdk 34.**
4. **Keep the pure-Java classes free of `android.*` imports:** `Wire`, `Crypto`, `PeerTable`, `HoldQueue`, `Geometry`. The desktop tests compile them with a plain JDK.
5. **Run the tests before every build:** `bash tests/run-tests.sh`. All must pass.
6. **Every release must raise `android:versionCode`** (currently 11) and update `android:versionName` (currently 1.0.1) in `AndroidManifest.xml`. Otherwise phones refuse to install it as an update.
7. **Always sign with the same `signing-key.jks`** (alias `walkie`). A different key means phones can't update the installed app. **Never generate a new key silently.** If the key or password is missing, stop and ask.
8. **Never commit `signing-key.jks` or `signing.env`.** Both are in `.gitignore`.
9. **ProGuard keeps only `MainActivity` and `RadioService` by name.** Any new component declared in the manifest (activity, service, receiver) needs a `-keep` rule in `proguard.pro`, or it gets renamed and the app crashes.
10. **Changing the packet format means raising `Wire.VERSION`.** Phones only accept packets with the same version byte, so old and new versions can't hear each other. Mention this to the user whenever a change breaks compatibility.
11. Code style: comments explain *why* in plain English, user-facing text is short and friendly, and every `catch` that ignores an error has a reason. Hostile network input must never crash the app.

---

## 3. File structure

```
AndroidManifest.xml       Package, version, permissions, MainActivity + RadioService
build.sh                  Builds and signs the APK (no Gradle)
proguard.pro              Shrink/optimize/obfuscate rules
README.md                 Public README for GitHub
PROJECT_CONTEXT.md        This file
.gitignore                Ignores *.jks, *.keystore, signing.env, build/, *.idsig
.gitattributes            *.sh kept with LF line endings; *.apk binary
signing-key.jks           (NOT in git) release signing key, alias "walkie"
signing.env               (NOT in git) WT_KEYSTORE_PASS=<password>
WalkieTalkie-1.0.1.apk    Current release build

res/
  drawable/ic_launcher_fg.xml   Launcher icon foreground (vector)
  drawable/ic_power.xml         Power icon (notification "Turn off" action)
  drawable/ic_stat.xml          Notification status-bar icon
  mipmap-anydpi-v26/ic_launcher.xml  Adaptive icon
  values/colors.xml             pitch #000000, white #FFFFFF, dialog #101010
  values/strings.xml            app_name "Walkie Talkie"
  values/themes.xml             Theme.Walkie (black, no action bar), Theme.Walkie.Dialog
  xml/data_extraction_rules.xml Excludes everything from cloud backup and device transfer

src/com/walkietalkie/wifi/
  MainActivity.java   (182)  The single screen; permissions; name dialog; actions from the view
  RadioView.java     (1432)  The whole UI, custom-drawn on one Canvas (no XML layouts)
  Geometry.java       (209)  Pixel positions of every UI element (pure Java)
  RadioEngine.java   (1056)  Core: network lifecycle, discovery, handshake, send/receive voice
  RadioService.java   (115)  Foreground service for background listening
  Crypto.java         (178)  ECDH + HKDF + AES-GCM (pure Java)
  Wire.java           (158)  Packet format, parser, name sanitizer (pure Java)
  PeerTable.java      (332)  Known radios and key-trust rules (pure Java)
  HoldQueue.java      (158)  Messages held while the line is busy (pure Java)
  AudioOut.java       (444)  Speaker playback, jitter buffer, level meter
  Sfx.java            (137)  Synthesized sound effects
  Prefs.java           (67)  SharedPreferences wrapper

tests/
  run-tests.sh        Compiles the pure-Java classes + tests with a desktop JDK and runs them
  SecTest.java        Crypto round trips, tamper detection, parser checks, fuzzing
  TrustTest.java      PeerTable trust rules (hijack, replay, proof)
  NetSim.java         Several simulated radios on a lossy, reordering network
  HoldTest.java       HoldQueue: order kept, nothing lost, memory bounded
  LayoutTest.java     Geometry on 27,880 window sizes, incl. scaled small windows
```

---

## 4. Build and signing

`build.sh` pipeline:

```
aapt package (resources, R.java)
  -> javac -source 8 -target 8 (against android-34.jar)
  -> ProGuard 7.4.2 (shrink, optimize 5 passes, obfuscate, repackage)
  -> dalvik-exchange --dex --min-sdk-version=26   (this is "dx")
  -> aapt add classes.dex
  -> zipalign -p 4
  -> apksigner sign (v2 + v3 schemes, min-sdk 31)
  -> apksigner verify
Output: WalkieTalkie.apk in the project root
```

Tool locations (each can be overridden with an environment variable):

| Variable | Default |
| --- | --- |
| `SDK_JAR` | `/opt/sdk/android-34.jar` |
| `JAVAC` | `/usr/lib/jvm/java-17-openjdk-amd64/bin/javac` |
| `PROGUARD` | `/opt/proguard-7.4.2/lib/proguard.jar` |
| `WT_KEYSTORE` | `signing-key.jks` |
| `WT_KEYSTORE_PASS` | read from `signing.env` if not already set |

`aapt`, `dalvik-exchange`, `zipalign` and `apksigner` must be on `PATH`. On Debian/Ubuntu these come from the `aapt`, `dalvik-exchange`, `zipalign` and `apksigner` packages. If `dx`/`dalvik-exchange` isn't available, `d8` from Android build-tools can replace that step, for example `d8 --min-api 26 --output build/dex build/min.jar`.

Signing: `build.sh` loads `signing.env` (one line: `WT_KEYSTORE_PASS=...`) unless `WT_KEYSTORE_PASS` is already set. The key alias is `walkie`.

Release steps:
1. Raise `versionCode` and `versionName` in `AndroidManifest.xml`.
2. `bash tests/run-tests.sh`, then check that everything passes.
3. `./build.sh`
4. Rename the output to `WalkieTalkie-<versionName>.apk`.

---

## 5. Architecture

### Components

- **`RadioEngine`** is a process-wide singleton (`RadioEngine.get(context)`). It owns the socket, crypto, peer table, hold queue and audio output. `MainActivity` and `RadioService` are both just views onto it, and register as `RadioEngine.Listener` to get `onRadioChanged()`. Change notifications are coalesced into one post on the main thread.
- **The radio runs when** `powered && (uiVisible || serviceHeld)`. `reconcile()` on the io thread starts or stops it.
- **`MainActivity`** sets a single `RadioView` as its content. It asks for the microphone and (on API 33+) notification permissions at first launch. In `onStop` it calls `engine.stopTx()`, so **the mic can never stay open when the app isn't on screen.**
- **`RadioService`** is a foreground service of type `mediaPlayback`, running only when power is on **and** "Always on" is enabled. Its ongoing notification shows "Listening on channel N", "Waiting for Wi-Fi" or "Radio is off", and has a "Turn off" action.

### Threads

| Thread | Job |
| --- | --- |
| main | Public API, UI, listeners |
| `wt-io` (HandlerThread) | Lifecycle, network callbacks, beacons, handshake retries, replay scheduling |
| `wt-rx` | Blocking `DatagramSocket.receive` loop; parses, decrypts and dispatches packets |
| `wt-tx` | Exists only while talking: mic, encrypt, send |
| AudioOut player | Exists only while sound plays; exits after 12 s idle |

### Networking lifecycle

- A `NetworkCallback` for `TRANSPORT_WIFI` (Wi-Fi without internet is fine) gives the Wi-Fi `Network`, IPv4 address and prefix.
- **Hotspot mode:** when this phone *is* the hotspot there's no Wi-Fi network to join, so `checkHotspot()` scans interfaces named `ap*`, `swlan*`, `wlan*`, `softap*` or `wigig*`. It polls every 4 s while the UI is visible and every 30 s in the background.
- `openSocket()` creates a **new `Crypto` (fresh key pair) every time**. It binds a UDP socket on **port 47321** with broadcast enabled and a 128 KB receive buffer, and **binds it to the Wi-Fi `Network`** so traffic can't leave over mobile data. It computes the subnet broadcast address and takes a `MulticastLock` on Wi-Fi.
- `closeSocket()` sends an encrypted BYE to everyone, clears the peer table and held messages, and releases the locks.
- IPv4 only. Packets from outside the local subnet, or from our own address, are ignored.

### Timing constants (RadioEngine)

| Constant | Value | Meaning |
| --- | --- | --- |
| `BEACON_FG_MS` | 15 s | Hello broadcast interval while the app is open |
| `BEACON_BG_MS` | 60 s | Hello interval in the background |
| `CHECKIN_MS` | 45 s | A backgrounded radio answers at most this often |
| `MAX_TALK_MS` | 3 min | Transmission time-out timer |
| `TALK_GATE_MS` | 120 ms | Mic audio is skipped while our own chirp plays |
| `REPLY_GAP_MS` | 2 s | At most one hello reply per radio per 2 s |
| `MAX_REPLIES_PER_SEC` | 10 | Total hello replies per second |
| `MAX_NEW_KEYS_PER_SEC` | 20 | ECDH key agreements per second |

---

## 6. Wire protocol (`Wire.java`)

UDP port **47321**, all numbers big-endian, `Wire.VERSION = 3`.

```
Header (12 bytes):
  [0]='W' [1]='T' [2]=version(3) [3]=type
  [4..7]  sender id (random 32-bit, never 0, stored in prefs)
  [8]     channel (1..16)
  [9]     flags
  [10..11] sequence number (AUDIO only)

HELLO  (plaintext, broadcast or unicast)
  header | public key (65 bytes, uncompressed P-256: 0x04|X|Y) | name length (1) | name UTF-8 (<= 80 bytes)
  flags: F_REPLY=1 ("please answer with your hello")

Sealed packets (AUDIO=2, END=3, BYE=4, PING=5, PONG=6)
  header | counter (8 bytes) | AES-GCM ciphertext | GCM tag (16)
  The header and counter are GCM associated data, so they are authenticated.
  AUDIO: 640 bytes of PCM (20 ms at 16 kHz mono 16-bit). Total packet 676 bytes.
  END / BYE / PING / PONG: empty payload (36 bytes).
  flags: F_DIRECT=2 on AUDIO/END = private call to one person.
```

- `parseHello` never throws. It refuses unknown flags, wrong exact length, channel outside 1–16, other versions and non-uncompressed keys.
- `cleanName` removes control, private-use and invisible format characters (including right-to-left overrides; only the emoji zero-width joiner is kept), collapses whitespace, caps names at 20 characters, and falls back to "Someone".

Message meanings:
- **HELLO**: "I'm here, this is my key, name and channel."
- **AUDIO**: one 20 ms voice frame, sent **unicast and encrypted separately to each listener**.
- **END**: "over". Sent 3 times, because UDP can drop packets. Listeners play the roger beep.
- **BYE**: leaving. Encrypted, so nobody can fake someone else leaving.
- **PING / PONG**: prove ownership of a key during the handshake.

---

## 7. Encryption (`Crypto.java`)

- A new **P-256 key pair per session**, created every time the socket opens, gives forward secrecy.
- **ECDH** → **HKDF-SHA256** (extract with a 32-byte zero salt; expand with info `"WalkieTalkie v3 pair key"` + both public keys in direction order) → one **AES-128-GCM** key per direction.
- **Nonce** = 12 bytes with a 64-bit per-session counter that only goes up. Receivers reject any counter ≤ the last accepted one (replay protection).
- Received public keys are **checked to lie on the curve** before use (stops invalid-curve attacks).
- Intermediate secrets are zero-filled after use.

## 8. Trust rules (`PeerTable.java`)

The handshake: HELLO → `NEW_KEY` → ECDH → stored as a **candidate** → we send our hello plus an encrypted **PING** → their sealed reply decrypts with the candidate key → **promoted** to trusted. Ping retries follow after 1, 2, 4 and 8 s.

Rules:
- A key is only used for sending audio after it's **proven**. Unproven candidates expire after **30 s**.
- An active radio's id can't be claimed from a different IP within **20 s** (`MOVE_GRACE_MS`).
- The last 4 keys a radio used are never accepted again (stops session replay).
- One radio per IP address, at most **64** radios.
- A radio that's silent for **120 s** (`TTL_MS`) is dropped.
- Unknown senders of sealed packets get a hello with `F_REPLY` ("who are you?"), at most once per 3 s per address.

## 9. Audio

**Sending (`RadioEngine.txLoop`, thread `wt-tx`):**
- `AudioRecord` with source `VOICE_COMMUNICATION`, 16 kHz, mono, PCM 16-bit. `NoiseSuppressor` and `AutomaticGainControl` are used when available.
- Reads 640-byte frames. The first 120 ms is skipped so our own chirp isn't transmitted.
- The target list is refreshed every 300 ms: everyone proven on the channel, or one person for a private call. The call ends with "X left the radio" if that person disappears.
- Changing channel mid-talk sends END on the old channel, then continues on the new one.
- Talking stops automatically after 3 minutes. Afterwards END is sent 3 times and any held messages play.
- If the mic can't open: "The microphone is busy in another app" plus a busy tone.
- **No codec:** raw PCM is about 32 KB/s per listener.

**Receiving (`AudioOut`):**
- One `AudioTrack` (usage MEDIA, content SPEECH) on its own thread, with transient audio focus that lets other audio duck.
- Frames come from a recycled pool, so there's no garbage per packet. The queue holds 96 entries; the oldest voice is dropped if it's badly behind.
- **Jitter buffer:** starts with 3 frames (60 ms) and grows if Wi-Fi is jittery. Stale voice is dropped to keep delay low.
- Silence for 700 ms without an END counts as "signal lost": the squelch tail plays without a roger beep.
- The audio track is released after 4 s of silence, and the thread exits after 12 s.
- The level meter is time-stamped so the visuals match what's being heard.

**Busy line (`HoldQueue`):** audio arriving while we talk, or while someone else is talking, is held in RAM. That's at most **8 messages** and **1500 frames (30 s, about 1 MB)** in total, and the oldest audio is dropped first. Held messages play in arrival order when the line is free. Changing channel drops held channel messages but keeps private ones.

**Sound effects (`Sfx`):** all synthesized in code at 16 kHz (about 50 KB); there are no audio files. POWER_ON, POWER_OFF, TALK_PERMIT (double chirp), SQUELCH_OPEN, ROGER_TAIL (roger beep plus squelch tail), TAIL (squelch tail only, when the signal drops), CHANNEL (blip), BUSY ("bonk"). All are skipped when Sounds is off.

## 10. User interface (`RadioView` + `Geometry`)

- A single custom `View` drawn on a `Canvas`: no XML layouts, no bitmaps, icons drawn in code.
- **Pitch-black look (since 1.0.1), high contrast:** every surface is black (`#000000`); parts are separated by grey outlines bright enough to stay visible at the lowest screen brightness (dark greys below about `#555` vanish there). `LINE #707070` (buttons, chips, panels, body), `LINE_DIM #606060` (grille), unlit grille dots `#666`, `PRESSED #303030`, avatars `#141414`, `GREY_TEXT #B0B0B0` (labels, sub-lines, hint), unlit digit segments `UNLIT #2C2C2C`, meter bars off `METER_OFF #555555`, chevrons `#C8C8C8 / #9A9A9A / #707070`, lock `#AAAAAA`. White is kept for text, the channel digits, the talk button and switched-on toggles. The slide track is the one gradient: `#333333` at the top fading to `#0D0D0D`, outline `#6A6A6A` (`#A0A0A0` while talking to everyone). The palette constants are at the top of `RadioView`.
- It redraws only when something changes, and runs a ~30 fps loop only while someone is talking. While the talk button's ripples move it uses `postInvalidateOnAnimation()` (screen frame rate); the level meter still steps every ~33 ms so it feels the same at any frame rate.
- Portrait only.
- **Small windows (since 1.0.1):** the layout needs 448dp of height and 300dp of width. Windows smaller than `Geometry.MIN_W_DP` × `MIN_H_DP` (320 × 460dp, e.g. split screen or a pop-up window) are laid out at that minimum size and drawn scaled down evenly by `fit = Geometry.fitScale(...)`; `onTouchEvent` divides touches by `fit`, so buttons answer where they're drawn. On normal phone screens `fit` is exactly 1 and nothing changes.

Layout, top to bottom:
1. **Header:** "Walkie Talkie" on the left, power button on the right.
2. **Speaker grille:** a dot matrix that lights up from the centre outwards with the voice level, like a VU meter.
3. **Display:** status light, title and subtitle, 7-segment channel number, and a footer with the network ("Wi-Fi 192.168.x.x" / "Hotspot ...") plus a level meter.
4. **Channel row:** − / + buttons (wrap 16 ↔ 1) with **your name plate** between them: your initial, your name and "Your name" under it, and a pencil. Tapping the plate (`R_NAME`) opens the rename dialog. The plate is sized to the name and centred; `Geometry.nameMinL/nameMaxR` keep it 10dp clear of the buttons.
5. **People row:** horizontally scrolling chips for **other people only**, sorted with your channel first. Each chip's sub-line says "Hold to talk" or "On channel N". **Holding a person's chip for 90 ms starts a private call**, and letting go ends it. Chips are as wide as their name (about 150dp minimum, names over 120dp end in "…"), so how many show depends on the names; the rest are reached by swiping. A fast swipe glides and slows down (`OverScroller`, the system's own fling speeds); touching the row stops the glide, and that touch never starts a private call. During a private call the chip turns solid white with black ink (initial on `#E4E4E4`, "Private call" in `#444444`, black mic); nothing is drawn outside the chip's edge, so the row can't clip it. It says "Private call" (short enough for the narrowest chip, and fitted to the chip anyway because phones can use wider system fonts), and the row scrolls so that chip is fully visible (`revealChip`). With nobody else around, the row shows "Others on this Wi-Fi show up here".
6. **Slide-to-talk track:** hold the knob to talk to the channel; slide it up to the lock to talk hands-free; tap to stop. The **Sounds** toggle is on one side and **Always on** on the other.
   - **Water drop (press only):** pressing the knob dips it (scale 0.86) and three rings spread from it; while you hold it in place, a new ring follows every 0.65–1.15 s (louder speech: more often, brighter, further). As soon as the finger slides up more than 10dp (`slid`), no new rings start, and a locked transmission has none. Rings are anchored at the knob's resting place, so ones already spreading don't follow the knob up. Letting go in place springs the knob back with a bounce and one last soft ring; sliding, locking, tapping to stop a locked talk, or leaving the app (`awayWhileTalking`) send no ring. Rings come from a fixed pool of 12 (no allocation per frame), are clipped to the body, and are skipped when the phone's "Remove animations" setting is on. Private calls don't ripple.
7. **Hint line:** for example "Hold to talk to everyone, slide up to lock".

Display titles: "Off" ("The radio is switched off"), "No Wi-Fi", "Talking" ("N people can hear you"), "Private" ("Only X can hear you" / "X is talking to you only"), "Listening" ("X is talking"), "Replay" (a held message is playing) and "Standby" ("N others here"). " (N messages waiting)" is appended when held messages are queued.

Short notices appear for 3.5 s through `engine.flash("...")`.

## 11. Settings (`Prefs`, SharedPreferences file `radio`)

| Key | Meaning | Default |
| --- | --- | --- |
| `id` | Random device id (SecureRandom, never 0) | generated |
| `callsign` | Display name | random, for example "Raven-42" |
| `channel` | 1–16 | 1 |
| `beep` | Sounds on | true |
| `background` | Always on (background listening) | true |
| `power` | Radio on | true |

`dropLegacy()` deletes an old `group` key: an earlier version had a private group code that was removed.

## 12. Permissions

`INTERNET` (sockets), `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`, `CHANGE_WIFI_MULTICAST_STATE` (receive broadcasts), `RECORD_AUDIO`, `WAKE_LOCK` (keep receiving while the screen is off), `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK`, `POST_NOTIFICATIONS`.

Manifest hardening: `allowBackup=false`, data extraction rules exclude everything, `usesCleartextTraffic=false`, and `RadioService` has `exported=false`.

## 13. Tests

`bash tests/run-tests.sh` compiles `Wire`, `Crypto`, `PeerTable`, `HoldQueue` and `Geometry` together with the tests on a desktop JDK 11+, then runs:
- **SecTest:** key agreement, encrypt/decrypt round trip, tampering at every byte detected, hello parsing and rejection cases, name cleaning, 300,000 fuzzed hellos and 20,000 random sealed packets (no crash, none accepted).
- **TrustTest:** hijack, replay and proof rules in `PeerTable`.
- **NetSim:** several radios with packet loss and reordering run the same hello → candidate → ping → pong → promote logic.
- **HoldTest:** held messages keep their order, lose nothing, and stay within memory bounds.
- **LayoutTest:** `Geometry` on 27,880 combinations of window size (240–900 × 300–1300 dp), density and text size, scaled with `fitScale` exactly like `RadioView`: normal screens are never scaled, the scaled radio always fits the window, sections never overlap, the name plate has at least 120dp and stays clear of the channel buttons' touch areas, the knob stays in its track and the side buttons stay clear of it, and when scaled the talk button stays at least 44dp and the channel buttons at least 30dp.

When changing protocol, crypto, trust, queue or layout logic, update or add tests here.

## 14. Known limitations (ideas for next versions)

1. **No access control.** Anyone on the same Wi-Fi with the app can join a channel and hear it. A group password could fix this, for example by mixing a shared secret into the HKDF or authenticating hellos.
2. **No identity verification.** ECDH is unauthenticated, so someone controlling the network could act as a man-in-the-middle. A "safety code" or fingerprint comparison screen would fix it.
3. **Metadata is visible.** Hellos are plaintext (name, id, channel), and headers are authenticated but not encrypted.
4. **No audio compression.** About 32 KB/s per listener, sent unicast to each one. A codec (for example Opus through `MediaCodec`) would cut bandwidth, but must avoid third-party libraries.
5. IPv4 and a single subnet only. Guest or isolated Wi-Fi networks block discovery.
6. Portrait only, English only, no settings screen beyond the two toggles and the name.

## 15. Version history

- **1.0.1 (versionCode 9):** UI only, so it still talks to 1.0.0 (protocol version 3 unchanged). Pitch-black look; your name plate replaces the "Change channel" label (tap it to rename); the people row shows only other people; the private-call chip turns solid white (no outer glow, so it's never clipped) and scrolls fully into view; slide track fades from dark grey to black; water-drop dip and ripples on the talk button. Split screen and pop-up windows: the radio scales down to fit instead of being cut off (below 448dp tall) or squeezed (below 300dp wide). No stray wave when you come back to the app after it stopped a locked transmission. High-contrast outlines, dots and grey labels so nothing vanishes at low screen brightness; waves only while the talk button is pressed in place (not while sliding up or locked). Private-call chip says "Private call" and can no longer run under the mic icon; the people row glides after a fast swipe. Added `LayoutTest`. (versionCodes 7–10 were earlier 1.0.1 test builds; 11 installs over all of them.)
- **1.0.0 (versionCode 6):** first release.
